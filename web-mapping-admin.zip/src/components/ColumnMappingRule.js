import React from 'react';
import { Table, Icon } from 'semantic-ui-react';

const ColumnMappingRule = (props) => {

 

    return (
        <div>
            <h2>Configure mapping rule</h2>
        </div>
    );
}

export default ColumnMappingRule;